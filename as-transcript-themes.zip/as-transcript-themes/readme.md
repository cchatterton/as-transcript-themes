# AS Transcript Themes

Author: AlphaSys  
Version: 0.2.1<br>
Status: MVP

## Purpose

Identifies topics, themes, and commitments from meeting transcripts and email threads using the WordPress 7 AI Client.

## Notes

- Requires WordPress 7.0 or later.
- Requires a configured AI provider through Settings > Connectors.
- Transcript and Email saves process changed content automatically.
- Transcript and Email editors use the classic editor and can auto-generate titles.
- Transcript and Email post content is the canonical processing input.
